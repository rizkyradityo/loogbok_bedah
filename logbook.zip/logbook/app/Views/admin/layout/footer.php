<?php 
use App\Models\Konfigurasi_model;
$session = \Config\Services::session();
$konfigurasi  = new Konfigurasi_model;
$site         = $konfigurasi->listing();
?>
<?php 
$sek  = date('Y');
$awal = $sek-100;
?>
<script>
  // $( ".datepicker" ).datepicker({
  //   inline: true,
  //   changeYear: true,
  //   changeMonth: true,
  //   dateFormat: "dd-mm-yy",
  //   yearRange: "<?php echo $awal ?>:<?php $tahundepan = date('Y')+2; echo $tahundepan; ?>"
  // });

  // $( ".tanggal" ).datepicker({
  //   inline: true,
  //   changeYear: true,
  //   changeMonth: true,
  //   dateFormat: "dd-mm-yy",
  //   yearRange: "<?php echo $awal ?>:<?php $tahundepan = date('Y')+2; echo $tahundepan; ?>"
  // });

  // $( ".tanggalan" ).datepicker({
  //   inline: true,
  //   changeYear: true,
  //   changeMonth: true,
  //   dateFormat: "dd-mm-yy",
  //   yearRange: "<?php echo $awal ?>:<?php $tahundepan = date('Y')+2; echo $tahundepan; ?>"
  // });

</script>
<!-- SWEETALERT -->
<?php if($session->getFlashdata('sukses')) { ?>
<script>
  swal("Berhasil", "<?php echo $session->getFlashdata('sukses'); ?>","success")
</script>
<?php } ?>

<?php if(isset($error)) { ?>
<script>
  swal("Oops...", "<?php echo strip_tags($error); ?>","warning")
</script>
<?php } ?>

<?php if($session->getFlashdata('warning')) { ?>
<script>
  swal("Oops...", "<?php echo $session->getFlashdata('warning'); ?>","warning")
</script>
<?php } ?>

<script>
// Sweet alert
function confirmation(ev) {
ev.preventDefault();
var urlToRedirect = ev.currentTarget.getAttribute('href'); //use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
console.log(urlToRedirect); // verify if this is the right URL
swal({
  title: "Yakin ingin menghapus data ini?",
  text: "Data yang sudah dihapus tidak dapat dikembalikan",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
  if (willDelete) {
    // Proses ke URL
    window.location.href = urlToRedirect;
  } 
});
} 

// Kirim ulang
function kirim(ev) {
ev.preventDefault();
var urlToRedirect = ev.currentTarget.getAttribute('href'); //use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
console.log(urlToRedirect); // verify if this is the right URL
swal({
  title: "Yakin Ingin Mengirim Surat Ini?",
  text: "Pengiriman Surat Sebaiknya Kurang dari 200 Kali/jam agar tidak terkena Blokir Server. Klik CANCEL untuk membatalkan. Klik OK untuk mengirim surat.",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
  if (willDelete) {
    // Proses ke URL
    window.location.href = urlToRedirect;
  } 
});
} 
// Akses
// Sweet alert
function akses(ev) {
ev.preventDefault();
var urlToRedirect = ev.currentTarget.getAttribute('href'); //use currentTarget because the click may be on the nested i tag and not a tag causing the href to be empty
console.log(urlToRedirect); // verify if this is the right URL
swal({
  title: "Yakin ingin memberi akses?",
  text: "Data yang diberi akses akan bisa login",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  // redirect with javascript here as per your logic after showing the alert using the urlToRedirect value
  if (willDelete) {
    // Proses ke URL
    window.location.href = urlToRedirect;
  } 
});
} 

// Tinymce

tinymce.init({
  selector: '.konten',
  menubar: true,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste code help wordcount'
  ],
  toolbar: 'undo redo | formatselect | bold italic strikethrough forecolor backcolor | link image | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat code',
  content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
});
</script>
</div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.1.0
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- bootstrap 4 -->
<script src="<?php echo base_url() ?>/assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url() ?>/assets/admin/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- dropzone -->
<script src="<?php echo base_url() ?>/assets/admin/plugins/dropzone/dropzone.js"></script>
<script>
$(document).ready(function(){
    // $('input.jam').timepicker({
    //     timeFormat: 'HH:mm:ss',
    //     // year, month, day and seconds are not important
    //     minTime: new Date(0, 0, 0, 8, 0, 0),
    //     maxTime: new Date(0, 0, 0, 15, 0, 0),
    //     // time entries start being generated at 6AM but the plugin 
    //     // shows only those within the [minTime, maxTime] interval
    //     startHour: 6,
    //     // the value of the first item in the dropdown, when the input
    //     // field is empty. This overrides the startHour and startMinute 
    //     // options
    //     startTime: new Date(0, 0, 0, 8, 20, 0),
    //     // items in the dropdown are separated by at interval minutes
    //     interval: 10
    // });
});
</script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>/assets/admin/dist/js/adminlte.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url() ?>/assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url() ?>/assets/admin/plugins/select2/js/select2.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url() ?>/assets/admin/plugins/select2/css/select2.min.css">
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>/assets/admin/dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
      "responsive": true, 
      "paging": true,
      "lengthMenu": [[100, 250, 500, -1], [100, 250, 500, "All"]],
      "lengthChange": true, 
      "autoWidth": false
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });

  $(function () {
    // Summernote
    $('.summernote').summernote({
      height: 100,                 // set editor height
      minHeight: null,             // set minimum height of editor
      maxHeight: null,             // set maximum height of editor
    })
  })
  // tanggal dan select
  // $(function () {
  //   //Initialize Select2 Elements
  //   $('.select2').select2()

  //   //Initialize Select2 Elements
  //   $('.select2bs4').select2({
  //     theme: 'bootstrap4'
  //   })

  //   //Datemask dd/mm/yyyy
  //   $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
  //   //Datemask2 mm/dd/yyyy
  //   $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
  //   //Money Euro
  //   $('[data-mask]').inputmask()

  //   //Date picker
  //   $('#reservationdate').datetimepicker({
  //       format: 'L'
  //   });

  //   //Date and time picker
  //   $('#reservationdatetime').datetimepicker({ icons: { time: 'far fa-clock' } });

  //   //Date range picker
  //   $('#reservation').daterangepicker()
  //   //Date range picker with time picker
  //   $('#reservationtime').daterangepicker({
  //     timePicker: true,
  //     timePickerIncrement: 30,
  //     locale: {
  //       format: 'MM/DD/YYYY hh:mm A'
  //     }
  //   })
  //   //Date range as a button
  //   $('#daterange-btn').daterangepicker(
  //     {
  //       ranges   : {
  //         'Today'       : [moment(), moment()],
  //         'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
  //         'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
  //         'Last 30 Days': [moment().subtract(29, 'days'), moment()],
  //         'This Month'  : [moment().startOf('month'), moment().endOf('month')],
  //         'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
  //       },
  //       startDate: moment().subtract(29, 'days'),
  //       endDate  : moment()
  //     },
  //     function (start, end) {
  //       $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
  //     }
  //   )

  //   //Timepicker
  //   $('#timepicker').datetimepicker({
  //     format: 'LT'
  //   })

  //   //Bootstrap Duallistbox
  //   $('.duallistbox').bootstrapDualListbox()

  //   //Colorpicker
  //   $('.my-colorpicker1').colorpicker()
  //   //color picker with addon
  //   $('.my-colorpicker2').colorpicker()

  //   $('.my-colorpicker2').on('colorpickerChange', function(event) {
  //     $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
  //   })

  //   $("input[data-bootstrap-switch]").each(function(){
  //     $(this).bootstrapSwitch('state', $(this).prop('checked'));
  //   })

  // })
  
  // // BS-Stepper Init
  // document.addEventListener('DOMContentLoaded', function () {
  //   window.stepper = new Stepper(document.querySelector('.bs-stepper'))
  // })

  // DropzoneJS Demo Code Start
  //Dropzone.autoDiscover = false

  // Get the template HTML and remove it from the doumenthe template HTML and remove it from the doument
  // var previewNode = document.querySelector("#template")
  // previewNode.id = ""
  // var previewTemplate = previewNode.parentNode.innerHTML
  // previewNode.parentNode.removeChild(previewNode)

  // var myDropzone = new Dropzone(document.body, { // Make the whole body a dropzone
  //   url: "/target-url", // Set the url
  //   thumbnailWidth: 80,
  //   thumbnailHeight: 80,
  //   parallelUploads: 20,
  //   previewTemplate: previewTemplate,
  //   autoQueue: false, // Make sure the files aren't queued until manually added
  //   previewsContainer: "#previews", // Define the container to display the previews
  //   clickable: ".fileinput-button" // Define the element that should be used as click trigger to select files.
  // })

  // myDropzone.on("addedfile", function(file) {
  //   // Hookup the start button
  //   file.previewElement.querySelector(".start").onclick = function() { myDropzone.enqueueFile(file) }
  // })

  // // Update the total progress bar
  // myDropzone.on("totaluploadprogress", function(progress) {
  //   document.querySelector("#total-progress .progress-bar").style.width = progress + "%"
  // })

  // myDropzone.on("sending", function(file) {
  //   // Show the total progress bar when upload starts
  //   document.querySelector("#total-progress").style.opacity = "1"
  //   // And disable the start button
  //   file.previewElement.querySelector(".start").setAttribute("disabled", "disabled")
  // })

  // // Hide the total progress bar when nothing's uploading anymore
  // myDropzone.on("queuecomplete", function(progress) {
  //   document.querySelector("#total-progress").style.opacity = "0"
  // })

  // // Setup the buttons for all transfers
  // // The "add files" button doesn't need to be setup because the config
  // // `clickable` has already been specified.
  // document.querySelector("#actions .start").onclick = function() {
  //   myDropzone.enqueueFiles(myDropzone.getFilesWithStatus(Dropzone.ADDED))
  // }
  // document.querySelector("#actions .cancel").onclick = function() {
  //   myDropzone.removeAllFiles(true)
  // }
  // DropzoneJS Demo Code End
</script>
</body>
</html>